import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
serve(async(req)=>{
 if(req.method!=="POST")return new Response("Method not allowed",{status:405});
 const auth=req.headers.get("Authorization");if(!auth)return Response.json({error:"Authentication required"},{status:401});
 const sb=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:auth}}});
 const {data:{user}}=await sb.auth.getUser();if(!user)return Response.json({error:"Unauthorized"},{status:401});
 const {availability,exam,examDate,commitments,mode,syllabus}=await req.json();
 if(!Array.isArray(availability)||availability.length>14)return Response.json({error:"Provide up to 14 availability entries."},{status:400});
 const key=Deno.env.get("OPENAI_API_KEY");if(!key)return Response.json({error:"AI service not configured"},{status:503});
 const prompt={exam,examDate,availability,commitments,mode,syllabus};
 const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({model:Deno.env.get("OPENAI_MODEL")||"gpt-4.1-mini",instructions:"Create a realistic study plan. Respect sleep, school/coaching and user availability. Never schedule outside supplied availability. Return JSON with an array of tasks: date,start,end,subject,chapter,activity,durationMinutes,priority,reason. Do not invent syllabus completion. This is a draft requiring user approval.",input:JSON.stringify(prompt)})});
 if(!r.ok)return Response.json({error:"AI provider failed"},{status:502});
 const d=await r.json();const text=(d.output||[]).flatMap((x:any)=>x.content||[]).filter((x:any)=>x.type==="output_text").map((x:any)=>x.text).join("");
 return Response.json({draft:text});
});
