create extension if not exists pgcrypto;
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Driver',
  exam text not null default 'JEE Main',
  exam_date date,
  planning_mode text not null default 'Balanced' check (planning_mode in ('Strict','Balanced','Flexible')),
  preferred_language text not null default 'English',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.study_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  subject text not null,
  chapter text not null default '',
  activity_type text not null default 'Theory',
  planned_minutes integer not null default 45 check (planned_minutes between 5 and 600),
  actual_minutes integer not null default 0 check (actual_minutes >= 0),
  question_target integer not null default 0 check (question_target >= 0),
  attempted integer not null default 0 check (attempted >= 0),
  correct integer not null default 0 check (correct >= 0 and correct <= attempted),
  status text not null default 'pending' check (status in ('pending','in_progress','completed','cancelled')),
  completed_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists public.xp_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  task_id uuid references public.study_tasks(id) on delete set null,
  amount integer not null,
  reason text not null,
  idempotency_key text not null,
  created_at timestamptz not null default now(),
  unique(user_id,idempotency_key)
);
create table if not exists public.syllabus_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  exam text not null,
  subject text not null,
  chapter text not null,
  status text not null default 'not_started' check(status in ('not_started','in_progress','completed','revision_needed')),
  updated_at timestamptz not null default now(),
  unique(user_id,exam,subject,chapter)
);
create table if not exists public.study_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'Weekly plan',
  plan jsonb not null,
  status text not null default 'draft' check(status in ('draft','approved','paused','archived')),
  created_at timestamptz not null default now()
);
create table if not exists public.mock_tests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  exam text not null,
  test_date date not null,
  duration_minutes integer,
  marks numeric,
  max_marks numeric,
  attempted integer not null default 0,
  correct integer not null default 0,
  notes text,
  created_at timestamptz not null default now()
);
create table if not exists public.vehicles (
  id integer primary key,
  name text not null unique,
  category text not null,
  unlock_level integer not null check(unlock_level > 0),
  style text not null
);
create table if not exists public.vehicle_ownership (
  user_id uuid not null references auth.users(id) on delete cascade,
  vehicle_id integer not null references public.vehicles(id),
  unlocked_at timestamptz not null default now(),
  primary key(user_id,vehicle_id)
);
create table if not exists public.vehicle_customizations (
  user_id uuid not null references auth.users(id) on delete cascade,
  vehicle_id integer not null references public.vehicles(id),
  config jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key(user_id,vehicle_id)
);
create table if not exists public.notification_identities (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  message_style text not null default 'encouraging',
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists public.saved_resources (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  url text,
  exam text,
  subject text,
  chapter text,
  notes text,
  created_at timestamptz not null default now()
);
create table if not exists public.music_playlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  url text not null,
  category text not null default 'Focus',
  created_at timestamptz not null default now()
);
do $$ declare t text; begin
  foreach t in array array['profiles','study_tasks','xp_transactions','syllabus_progress','study_plans','mock_tests','vehicle_ownership','vehicle_customizations','notification_identities','saved_resources','music_playlists'] loop
    execute format('alter table public.%I enable row level security',t);
    execute format('create policy "Users manage own %I" on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)',t,t);
  end loop;
end $$;
-- profiles uses id rather than user_id
alter table public.profiles enable row level security;
create policy "Users manage own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,display_name) values(new.id,coalesce(new.raw_user_meta_data->>'display_name','Driver')); return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
