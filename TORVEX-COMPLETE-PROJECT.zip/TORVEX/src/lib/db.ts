import Dexie, { type Table } from "dexie";
export type LocalTask = { id:string; title:string; subject:string; chapter:string; minutes:number; done:boolean; createdAt:string; xpAwarded:boolean };
class TorvexDB extends Dexie {
  tasks!: Table<LocalTask, string>;
  constructor(){ super("torvex-local"); this.version(1).stores({ tasks:"id, done, subject, createdAt" }); }
}
export const db = new TorvexDB();
