import { useState } from "react";
import { supabase } from "../lib/supabase";
export default function Assistant(){
 const [open,setOpen]=useState(false),[q,setQ]=useState(""),[answer,setAnswer]=useState("Ask me about your study plan, concepts or TORVEX."),[busy,setBusy]=useState(false);
 async function ask(){if(!q.trim())return;setBusy(true);try{
   if(!supabase) throw new Error("Connect Supabase and deploy the AI Edge Function to enable the assistant.");
   const {data,error}=await supabase.functions.invoke("ai-assistant",{body:{message:q}});
   if(error)throw error;setAnswer(data.answer||"I couldn't create a response.");
 }catch(e){setAnswer(e instanceof Error?e.message:"Assistant unavailable.");}finally{setBusy(false);}}
 return <><button className="assistant-fab" onClick={()=>setOpen(!open)} aria-label="Open AI assistant">✦</button>{open&&<section className="assistant-panel"><header><b>TORVEX AI</b><button onClick={()=>setOpen(false)}>×</button></header><p>{answer}</p><div className="inline-form"><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&ask()} placeholder="Ask your assistant…"/><button onClick={ask} disabled={busy}>{busy?"…":"Send"}</button></div><small>AI answers require a configured, authenticated backend.</small></section>}</>;
}
