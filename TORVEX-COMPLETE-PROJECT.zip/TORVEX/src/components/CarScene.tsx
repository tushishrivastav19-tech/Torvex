import { Canvas } from "@react-three/fiber";
import { ContactShadows, Environment, OrbitControls, Stage } from "@react-three/drei";
import { Suspense } from "react";
import * as THREE from "three";
function ProceduralCar({ color, variant=0 }:{color:string;variant?:number}) {
  const paint = new THREE.MeshStandardMaterial({ color, metalness:.82, roughness:.22 });
  const glass = new THREE.MeshPhysicalMaterial({color:"#172536",metalness:.5,roughness:.12,clearcoat:1});
  const tire = new THREE.MeshStandardMaterial({color:"#101216",roughness:.9});
  return <group position={[0,-.15,0]}>
    <mesh position={[0,.58,0]} castShadow material={paint}><boxGeometry args={[2.2,.48,4.1]} /></mesh>
    <mesh position={[0,.96,-.25]} castShadow material={paint}><boxGeometry args={[1.72,.62,2.1]} /></mesh>
    <mesh position={[0,1.0,-.25]} material={glass}><boxGeometry args={[1.75,.46,1.92]} /></mesh>
    <mesh position={[0,.78,1.5]} material={paint}><boxGeometry args={[2.05,.16,.7]} /></mesh>
    {[-1,1].map(x=>[-1.28,1.28].map(z=><group key={`${x}-${z}`} position={[x*1.02,.38,z]}>
      <mesh rotation={[0,0,Math.PI/2]} material={tire}><cylinderGeometry args={[.39,.39,.22,24]} /></mesh>
      <mesh rotation={[0,0,Math.PI/2]} material={new THREE.MeshStandardMaterial({color:"#9da7b4",metalness:.9,roughness:.2})}><cylinderGeometry args={[.22,.22,.235,16]} /></mesh>
    </group>))}
    <mesh position={[0,.48,-2.02]} material={paint}><boxGeometry args={[2.25,.18,.16]} /></mesh>
    <mesh position={[0,.98,1.94]} material={paint}><boxGeometry args={[1.65,.08,.25]} /></mesh>
    <mesh position={[0,.4,2.08]} material={new THREE.MeshStandardMaterial({color:"#e33b45",emissive:"#6d1018"})}><boxGeometry args={[1.35,.12,.04]} /></mesh>
  </group>;
}
export default function CarScene({color="#c5ced9",variant=0}:{color?:string;variant?:number}) {
  return <div className="car-scene"><Canvas shadows camera={{position:[5,3.1,6],fov:42}} dpr={[1,1.6]}>
    <Suspense fallback={null}><color attach="background" args={["#0b111b"]}/><ambientLight intensity={.55}/><spotLight position={[5,8,5]} intensity={2.2} angle={.45} castShadow/><Stage environment="city" intensity={.45} adjustCamera={false}><ProceduralCar color={color} variant={variant}/></Stage><ContactShadows position={[0,-.02,0]} opacity={.45} blur={2.5}/><Environment preset="city"/></Suspense>
    <OrbitControls enablePan={false} minDistance={4} maxDistance={10} maxPolarAngle={Math.PI/2.05}/>
  </Canvas></div>;
}
