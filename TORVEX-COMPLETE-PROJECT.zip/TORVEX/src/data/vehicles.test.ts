import { describe, expect, it } from "vitest";
import { vehicles } from "./vehicles";
describe("vehicle catalogue",()=>{it("contains 30 uniquely named vehicles",()=>{expect(vehicles).toHaveLength(30);expect(new Set(vehicles.map(v=>v.name)).size).toBe(30);});});
