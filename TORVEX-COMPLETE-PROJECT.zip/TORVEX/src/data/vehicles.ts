export type Vehicle = { id:number; name:string; category:"Basic"|"Supercar"|"Hypercar"|"Legendary"; style:string; color:string; unlockLevel:number; description:string };
const names = [
["Apex R1","Basic","Roadster","#aeb9c8",1],["Vanta S","Basic","Coupe","#e33b45",1],["Circuit GT","Basic","Sport","#2879c7",2],
["Nova RS","Basic","Hatchback","#d6dbe3",3],["Falcon XR","Basic","Rally","#e6a23c",4],["Vector 9","Basic","Track","#6e91b8",5],
["Tempest V8","Supercar","Grand Tourer","#b9c2ce",7],["Ardent X","Supercar","Mid-engine","#db343e",9],["Monarch GT","Supercar","Luxury Coupe","#d6b36a",11],
["Striker R","Supercar","Track Special","#f1f1f1",13],["Phantom S","Supercar","Performance Coupe","#525d6c",15],["Onyx RS","Supercar","Sport Coupe","#293b55",17],
["Eclipse 720","Supercar","Super Sport","#a8b4c4",19],["Razorback","Supercar","Track Special","#c84632",21],["Solstice GT","Supercar","Grand Tourer","#8d9eaa",23],
["Aether One","Hypercar","Hybrid Hypercar","#8cb9d7",25],["Vortex X","Hypercar","Track Hypercar","#e33b45",27],["Zenith R","Hypercar","Aero Hypercar","#c3c8d0",29],
["Nebula 9","Hypercar","Electric Hypercar","#7e8ee8",31],["Aquila LM","Hypercar","Prototype","#f0f0eb",33],["Titanium K","Hypercar","V12 Hypercar","#9b9b9b",35],
["Spectre 8","Hypercar","Carbon Hypercar","#333943",37],["Velocity Z","Hypercar","Concept Hypercar","#d7a5be",39],["Aurora GT","Hypercar","Hybrid Track","#71b5a6",41],
["Apex Phantom","Legendary","Prototype Legend","#e6e6e6",45],["Crimson Reign","Legendary","Track Icon","#9d2634",50],
["Silver Wraith","Legendary","Grand Touring Icon","#c4ccd6",55],["Blue Comet","Legendary","Electric Prototype","#4d83d4",60],
["Obsidian Crown","Legendary","Ultimate Hypercar","#343b47",70],["TORVEX S-01","Legendary","Signature One-off","#d8dde4",80]
] as const;
export const vehicles:Vehicle[] = names.map((v,i)=>({id:i+1,name:v[0],category:v[1],style:v[2],color:v[3],unlockLevel:v[4],description:`${v[2]} class vehicle with a distinct TORVEX collection identity.`}));
